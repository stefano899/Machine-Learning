# Chip-Counting > 2025-08-04 8:23pm
https://universe.roboflow.com/stefano-xb5jc/chip-counting-rovys-48xvw

Provided by a Roboflow user
License: CC BY 4.0

